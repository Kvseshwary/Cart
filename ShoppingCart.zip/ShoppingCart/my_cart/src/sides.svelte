<div class="card">
      <img src='side.png' alt="side" style="width:60%">
       <div class="container">
       <h4><b>Pizza</b></h4> 
       <p><button on:click={handleClick}>Add To Cart {count} {count === 1 ? 'Item' : 'Items'}</button></p> 
  </div>
</div>
  